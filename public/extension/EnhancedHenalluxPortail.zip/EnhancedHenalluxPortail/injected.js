function getPromotions() 
{
    var config = { headers: {Authorization: `Bearer ${auth_user_token}`}, };

    axios.get(`/api/classes/my`, config)
        .then(function (response) {
            if(response.status === 200) 
            {
                window.postMessage({ type: "PROMOTIONS_DATA", data: response.data.data }, "*");
            }
            else if(response.status === 202) 
            {
                console.log(response.data);
            }
        })
        .catch(function (error) 
        {
            console.log(error);
        });
}

function customSectionPromotion(id)
{
    var config = { headers: {Authorization: `Bearer ${auth_user_token}`}, };

        let url = `/api/plannings/promotion/${id}`
        console.log(url)
        axios.get(url, config)
            .then(function (response) {
                if( response.status == 200 )
                {
                    planning_current_url = url

                    window.postMessage({ type: "CUSTOM_SECTION_PROMOTION_DATA", data: response.data }, "*");
                }
            })
            .catch(function (error) 
            {
                console.log(error);
            });
}

function modalLocaux()
{
    openModalLocaux();
}

function setCalendarEvents(events)
{
    set_calendar_events(events.data);
    
    // send message to content.js
    window.postMessage({ type: "CALENDAR_EVENTS_SET" }, "*");
}

function getToken()
{
    navigator.clipboard.writeText(auth_user_token);
}

function valveAll()
{
    var config = {
        headers: {
            Authorization: `Bearer ${auth_user_token}`
        },
    };
    console.log(auth_user_token);
    console.log(axios.get('/api/valves', config));
    axios.get('/api/valves', config)
        .then(function (response) {
            // datas exists
            if( response.data.success )
            {
                console.log(response.data.data);
                let nb_valves = 0;
                response.data.data.forEach( valve_datas =>
                {


                    let dates_ok = true; // always true to ignore date check

                    // check visibilty critera
                    if(true /*valve_datas['status'] == 'publish' && valve_datas['priority'] != 'emergency' && dates_ok*/  )
                    {
                        // button icon style
                        let icon_priority = ''
                        if( valve_datas['priority'] === 'low')
                            icon_priority = '<i class="fas fa-minus-square float-left"></i>'
                        if( valve_datas['priority'] === 'normal')
                            icon_priority = '<i class="fas fa-equals float-left"></i>'
                        if( valve_datas['priority'] === 'high')
                            icon_priority = '<i class="fas fa-exclamation-circle float-left"></i>'
                        if( valve_datas['priority'] === 'emergency')
                            icon_priority = '<i class="fas fa-burn float-left"></i>'

                        // color for valve
                        let class_priority = `valve-priority-${valve_datas['priority']}`

                        // color for readed vavles
                        let class_readed = valve_datas['readed_at'] ? 'fa-check-square' : 'fa-square'

                        // escape content
                        let content = valve_datas['content'].replace(/&/g, '&amp;')
                            .replace(/</g, '&lt;')
                            .replace(/>/g, '&gt;')
                            .replace(/"/g, '&quot;')
                            .replace(/'/, '&apos;')
                            .replace(/`/, '&apos;');

                        // create html structure with datas
                        let valve_html = `<button type="button" class="btn btn-primary valve ${class_priority}"
                                                data-toggle="modal"
                                                data-target="#valveModal"
                                                data-class_priority="${class_priority}"
                                                data-priority="${valve_datas['priority']}"
                                                data-id="${valve_datas['id']}"
                                                data-title="${valve_datas['title']}"
                                                data-author="${valve_datas['author']}"
                                                data-author_id="${valve_datas['author_id']}"
                                                data-editor="${valve_datas['editor']}"
                                                data-content="${content}"
                                                data-begin_at="${valve_datas['begin_at']}"
                                                data-end_at="${valve_datas['end_at']}"
                                                data-liked_at="${valve_datas['liked_at']}"
                                                data-readed_at="${valve_datas['readed_at']}"
                                                data-groups_id="${valve_datas['groups_id']}"
                                                >
                                        ${icon_priority}<span>${valve_datas['title']}</span><i class="far ${class_readed} float-right"></i>
                                        </buttonn>`;

                        // add to list
                        jQuery("#valves-list").append(valve_html);

                        // total
                        nb_valves++
                }
                });

                // msg if 0 valves
                if( nb_valves == 0 )
                {
                    jQuery('#valves-msg').html('<i class="fas fa-exclamation">  Aucun valves à afficher</i>')
                    jQuery('#valves-msg').show();
                }

                // actions
                $( ".valve" ).click( vlv_open_modal_action )

                // set initial list view
                $( '.valve i.far.fa-check-square' ).parent().hide() 

                filterAll(); // show valves even if already readed
            }
            else
            {
                cobsole.log("error");
            }
        })
        .catch(function (error) {
            console.log(error);
        });
}

window.addEventListener('message', (event) => 
{
    // We only accept messages from ourselves
    if (event.source != window)
        return;

    if (event.data.type && (event.data.type == "CALL_GET_PROMOTIONS"))
    {
        getPromotions();
    }

    if (event.data.type && (event.data.type == "CUSTOM_SECTION_PROMOTION"))
    {
        customSectionPromotion(event.data.customId);
    }

    if (event.data.type && (event.data.type == "SET_CALENDAR_EVENTS"))
    {
        setCalendarEvents(event.data);
    }

    if (event.data.type && (event.data.type == "MODAL_LOCAUX"))
    {
        modalLocaux();
    }

    if (event.data.type && (event.data.type == "GET_TOKEN"))
    {
        getToken();
    }

    if(event.data.type && (event.data.type == "EXPORT_SETTINGS"))
    {
        exportSettings();
    }
        

    // VALVES_ALL
    if (event.data.type && (event.data.type == "VALVES_ALL"))
    {
        valveAll();
    }

}, false);

function exportSettings()
{
    let currentLocalStorages = localStorage;
    let settings = 
    {
        "token" : auth_user_token,
        "colors" : 
        {
            "0" : currentLocalStorages.getItem("colorB1") || null,
            "1" : currentLocalStorages.getItem("colorB2") || null,
            "2" : currentLocalStorages.getItem("colorB3") || null,
            "3" : currentLocalStorages.getItem("colorOther") || null,
        },
        "promotions" : currentLocalStorages.getItem("promotions") || null,
        "classes" : currentLocalStorages.getItem("classes") || null,

    };

   // copy to clipboard
    navigator.clipboard.writeText(JSON.stringify(settings));

}

function set_action_planning()
    {
        let type = $('#plannings-filter-mobile > div > div > select').val()

        switch (type)
        {
            case 'my':
                axios_get_my_planning()
                break;
            case 'locaux':
                openModalLocaux()
                break;
            case 'section':
                openModalSection()
                break;
            case 'promo':
                openModalPromo()
                break;
            case 'custom':
                console.log('personnalisé');
                window.postMessage({ type: "CUSTOM_SECTION_PROMOTION_LIST" }, "*");
                break;

            case 'settings':
                window.postMessage({ type: "SETTINGS_LIST" }, "*");
                break;
      
            case 'collegue':
                openModalCollegue()
                break;
            case 'help':
                $('#helpPlannings').modal('show')
                break;
            case 'ical':
                download_planning()
                break;
        }

    }

    function next_select(event, type)
    {
        let values = $(event).val();

        if( values.length > 0 )
        {
            let url = ''
            let id_implantation = ''
            let id_orientation = ''
            switch (type)
            {
                // Locaux
                case 'locaux':
                    url = `/api/locals/implantation/${values}`
                    axios_get_datas_option(url, '#locaux-select', 'Locaux', 'api-locaux', true)
                    break;
                case 'api-locaux':
                    axios_get_locals_planning(JSON.stringify(values))
                    break;
                // Orientations
                case 'orientations':
                    url = `/api/orientations/implantation/${values}`
                    axios_get_datas_option(url, '#promo-orientation-select', 'Orientations', 'years', false )
                    break;
                case 'years':
                    id_implantation = $('#promo-implantation-select > div > select').val()
                    id_orientation = values
                    url = `/api/classes/orientation_and_implantation/${id_orientation}/${id_implantation}`
                    axios_get_datas_option(url, '#promo-year-select', 'Année', 'classes', false )
                    break;
                case 'classes':
                    id_implantation = $('#promo-implantation-select > div > select').val()
                    id_orientation = $('#promo-orientation-select > div > select').val()
                    id_classe = values
                    url = `/api/classes/classe_and_orientation_and_implantation/${id_classe}/${id_orientation}/${id_implantation}`
                    axios_get_datas_option(url, '#promo-classe-select', 'Classe', 'api-promo', true )
                    break;
                case 'api-promo':
                    axios_get_promos_planning(JSON.stringify(values))
                    break;
                // collegues
                case 'collegues':
                    url = `/api/personnels/implantation/${values}`
                    axios_get_datas_option(url, '#collegues-collegue-select', 'Collegues', 'api-collegue', true)
                    break;
                case 'api-collegue':
                    url = `/api/personnels/implantation/["${values}"]`
                    console.log(2)
                    axios_get_datas_option(url, '#collegues-collegue-select', 'Collegues', 'api-collegue', true)
                    break;
                // section
                case 'api-section':
                    axios_get_section_planning(JSON.stringify(values))
                    break;
            }
        }
    }

    function axios_get_datas_option(url, parent, title, next, is_multiple)
    {
        var config = { headers: {Authorization: `Bearer ${auth_user_token}`}, };

        axios.get(url, config)
            .then(function (response) 
            {
                // cleans olds msg for user
                $( parent ).find('.alert').empty()

                // log all datas
                console.log(response);

                if( response.status == 200 )
                {
                    add_selectbox(response.data.data, parent, title, next, is_multiple)
                }
                else
                {
                    // TODO msg to user
                    set_options_msg(parent, 'Aucune donnée trouvée pour ce choix');
                }

            })
            .catch(function (error) {
                console.log(error);
            });
    }


  