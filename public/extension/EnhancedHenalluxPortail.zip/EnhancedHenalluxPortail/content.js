const calendarTools = document.getElementById('calendar-tools');
const selectCalendarOption = document.getElementsByClassName('mdb-select md-form initialized')[2]
const valvesSearch = document.getElementsByClassName('valves-search')[0];
const valves = document.getElementById('valves-list');
let settingsContainer;
let promotions = [];
let classes = [];
let classOtherList;
let classesB1List;
let classesB2List;
let classesB3List;

const script = document.createElement('script');
script.src = chrome.runtime.getURL('injected.js');

(document.head || document.documentElement).appendChild(script);

const style = document.createElement('link');
style.rel = 'stylesheet';
style.type = 'text/css';
style.href = chrome.runtime.getURL('style.css');

(document.head || document.documentElement).appendChild(style);

window.addEventListener('message', function(event) {
    // We only accept messages from ourselves
    if (event.source != window)
        return;


    if(event.data.type && event.data.type == "CUSTOM_SECTION_PROMOTION_LIST")
    {
        customSectionPromotion();
    }

    if(event.data.type && event.data.type == "SETTINGS_LIST")
    {
        openSettings();
    }

    if (event.data.type && event.data.type == "PROMOTIONS_DATA")
    {
        promotions = event.data.data;
        createSettingsContainer();

        if(localStorage.getItem('autoCustom') !== null && JSON.parse(localStorage.getItem('autoCustom')) === true)
        {
            customSectionPromotion();
        }
    }


    if (event.data.type && event.data.type == "CUSTOM_SECTION_PROMOTION_DATA")
    {
        classes = [];

        event.data.data.forEach(element =>
        {
            let title = element.title.split('-')[0];
            if(title.includes('UE ')){
                title = element.title.split('-')[1];
                // remove first space
                title = title.substring(1);
            }
     
            let length = 0; 
            if (element.title.includes('[') && !element.title.endsWith('[')) {
                length = element.title.split('[')[1].length;
            }

            let year = 0;
            if(length > 1)
            {
                years = [];
                let i = 0;
                while(i < element.title.length)
                {
                    if(element.title[i] == '[')
                    {
                        // check if there is a space after the [, cause they fucked up the format
                        
                        if(element.title[i+1] == ' ')
                        {
                            years.push(element.title[i+2]);
                            i++;
                        }
                        else
                        {
                            years.push(element.title[i+1]);
                        }                       
                    }
                    i++;
                }
                
                if(years.length >= 1)
                {
                    let allSameYear = years.every( (val, i, arr) => val === arr[0] );
                    if(allSameYear)
                    {
                        year = years[0];
                    }
                    else
                    {
                        year = 0;
                    }
                }
                
            }
            
            if(!classes[year])
            {
                classes[year] = [];
            }

            if(!classes[year].includes(title))
            {
                classes[year].push(title);
            }            
        });
        fillClasses();

    
        event.data.data.forEach(element => 
        {
            // remove from event.data.data unchecked classes
            let classesChecked = JSON.parse(localStorage.getItem('classes')) || [];
            let title = element.title.split('-')[0];
            if(title.includes('UE ')){
                title = element.title.split('-')[1];
                // remove first space
                title = title.substring(1);
            }
            let length = 0;
            if (element.title.includes('[') && !element.title.endsWith('[')) 
            {
                length = element.title.split('[')[1].length;
            }

            let year = 0;
            if(length > 1)
            {
                years = [];
                let i = 0;
                while(i < element.title.length)
                {
                    if(element.title[i] == '[')
                    {
                        // check if there is a space after the [, cause they fucked up the format
                        
                        if(element.title[i+1] == ' ')
                        {
                            years.push(element.title[i+2]);
                            i++;
                        }
                        else
                        {
                            years.push(element.title[i+1]);
                        }                       
                    }
                    i++;
                }
                
                if(years.length >= 1)
                {
                    let allSameYear = years.every( (val, i, arr) => val === arr[0] );
                    if(allSameYear)
                    {
                        year = years[0];
                    }
                    else
                    {
                        year = 0;
                    }
                }
                
            }

        
            
            

            // check if title is found in classesChecked and if the year is the same
            if(classesChecked.some(item => item.classe === title && item.year == year))
            {
                event.data.data = event.data.data.filter(e => e.title !== element.title);
            }

            


        });

        window.postMessage({ type: "SET_CALENDAR_EVENTS", data: event.data.data }, "*");
    }

    if (event.data.type && event.data.type == "CALENDAR_EVENTS_SET")
    {
        // wait until calendar events are set to update colors. avoid a non colored event
        updateColors();
    }   

}, false);

window.onload = function()
{
    window.postMessage({ type: "CALL_GET_PROMOTIONS" }, "*");
    addSelectCalendarOptions();
    createValvesAllButton();
    clearValvesButton();
    modalLocaux();

    const customDiv = document.createElement('div');
    calendarTools.appendChild(customDiv);
    createCustomButton(customDiv);
    createSettingsButton(customDiv);
    createTokenButton(customDiv);
    createExportSettingsButton(customDiv);


};

function createValvesAllButton()
{
    const valvesAllButton = document.createElement('button');
    valvesAllButton.innerHTML = "Voir tous";
    // classes btn btn-light px-3 valve-priority-normal waves-effect
    valvesAllButton.classList.add("btn", "btn-light", "px-3", "valve-priority-normal", "waves-effect");
    // Tooltip text
    valvesAllButton.setAttribute('title', 'Afficher toutes les valves depuis 2019');

    

    valvesAllButton.onclick = function() 
    {
        window.postMessage({ type: "VALVES_ALL" }, "*");
    };

    valvesSearch.appendChild(valvesAllButton);
}

function clearValvesButton()
{
    const clearValves = document.createElement('button');
    clearValves.innerHTML = "Effacer";
    // classes btn btn-light px-3 valve-priority-high waves-effect
    clearValves.classList.add("btn", "btn-light", "px-3", "valve-priority-high", "waves-effect");
    clearValves.onclick = function() 
    {
        valves.innerHTML = '';
    };

    valvesSearch.appendChild(clearValves);
}

function addSelectCalendarOptions()
{
    let thirdOption = selectCalendarOption.children[2];

    const optionLocaux = document.createElement('option');
    optionLocaux.value = "locaux";
    optionLocaux.textContent = "Locaux";

    const customOption = document.createElement('option');
    customOption.value = "custom";
    customOption.textContent = "Personnalisé";
    
    const settingsOption = document.createElement('option');
    settingsOption.value = "settings";
    settingsOption.textContent = "Paramètres";

    const grabTokenOption = document.createElement('option');
    grabTokenOption.value = "grabToken";
    grabTokenOption.textContent = "Récupérer le token";


    selectCalendarOption.insertBefore(settingsOption, thirdOption.nextSibling);
    selectCalendarOption.insertBefore(customOption, thirdOption.nextSibling);
    selectCalendarOption.insertBefore(optionLocaux, thirdOption.nextSibling);
    selectCalendarOption.insertBefore(grabTokenOption, thirdOption.nextSibling);
}

function createCustomButton(div)
{
    const customCalendarButton = document.createElement('button');
    customCalendarButton.innerHTML = "Personnaliser";
    customCalendarButton.classList.add("btn", "btn-primary", "waves-effect", "waves-light");
    customCalendarButton.onclick = function() 
    {
        customSectionPromotion();
    };
    div.appendChild(customCalendarButton);
}

function createSettingsButton(div)
{
    const settingsButton = document.createElement('button');
    settingsButton.innerHTML = "Paramètres";
    settingsButton.id = "settingsButton";
    settingsButton.classList.add("btn", "btn-secondary");
    settingsButton.onclick = function() 
    {
        openSettings();
    };
    div.appendChild(settingsButton);
}

function createTokenButton(div)
{
    const grabTokenButton = document.createElement('button');
    grabTokenButton.innerHTML = "Récupérer le token";
    grabTokenButton.id = "grabTokenButton";
    grabTokenButton.classList.add("btn", "btn-secondary");
    grabTokenButton.onclick = function() 
    {
        window.postMessage({ type: "GET_TOKEN"}, "*");
    };

    div.appendChild(grabTokenButton);
}

function createExportSettingsButton(div)
{
    const exportSettingsButton = document.createElement('button');
    exportSettingsButton.innerHTML = "Exporter les paramètres";
    exportSettingsButton.classList.add("btn", "btn-secondary");
    exportSettingsButton.onclick = function() 
    {
        window.postMessage({ type: "EXPORT_SETTINGS" }, "*");
    };

    div.appendChild(exportSettingsButton);
}

function customSectionPromotion()
{
    var ids;

    const promotionsChecked = JSON.parse(localStorage.getItem('promotions')) || [];

    // id changed every day, so we need to get the real id from the promotion_id
    let realPromotionsIds = [];
    console.log(promotions);
    promotionsChecked.forEach(promotionId => 
    {
        promotions.forEach(promotion => {
            if(promotion.promotion_id == promotionId)
            {
                realPromotionsIds.push(promotion.id);
            }
        });
    });

    ids = "[" + realPromotionsIds.join(",") + "]";

    window.postMessage({ type: "CUSTOM_SECTION_PROMOTION", customId: ids }, "*");
}

function modalLocaux()
{
    const modalLocauxButton = document.createElement('button');
    modalLocauxButton.innerHTML = "Locaux";
    modalLocauxButton.classList.add("btn", "btn-primary", "waves-effect", "waves-light");
    modalLocauxButton.onclick = function() 
    {
        window.postMessage({ type: "MODAL_LOCAUX" }, "*");
    };
    calendarTools.appendChild(modalLocauxButton);
}

function createSettingsContainer()
{
    settingsContainer = document.createElement('div');
    settingsContainer.classList.add("settings-container");

    
    document.body.appendChild(settingsContainer);

    document.addEventListener('click', function(event) 
    {
        if(!settingsContainer.contains(event.target) && event.target.id !== 'settingsButton')
        {
            closeSettings();
        }
    });

    const clearLocalStorageButton = document.createElement('button');
    clearLocalStorageButton.innerHTML = "Supprimer les données";
    clearLocalStorageButton.classList.add("btn", "btn-danger");
    clearLocalStorageButton.style.marginBottom = "20px";
    clearLocalStorageButton.onclick = function() 
    {
        localStorage.clear();
        location.reload();
    };

    settingsContainer.appendChild(clearLocalStorageButton);
    const autoCustom = document.createElement('div');
    autoCustom.classList.add("settings-auto-custom-button");

    const autoCustomLabel = document.createElement('label');
    autoCustomLabel.textContent = "Charger automatiquement les classes sélectionnées au lancement de la page";
    autoCustomLabel.style.marginRight = "10px";

    const autoCustomCheckbox = document.createElement('input');
    autoCustomCheckbox.type = 'checkbox';
    autoCustomCheckbox.classList.add("settings-checkbox");


    autoCustom.appendChild(autoCustomLabel);
    autoCustom.appendChild(autoCustomCheckbox);
    settingsContainer.appendChild(autoCustom);


    if(localStorage.getItem('autoCustom') !== null)
    {
        autoCustomCheckbox.checked = JSON.parse(localStorage.getItem('autoCustom'));
    }

    autoCustomCheckbox.addEventListener('change', function(event)
    {
        localStorage.setItem('autoCustom', this.checked);
    }); 


    const promotionsHeader = document.createElement('div');
    promotionsHeader.classList.add("settings-header");
    promotionsHeader.textContent = "CLASSES";

    const colorPickersHeader = document.createElement('div');
    colorPickersHeader.classList.add("settings-header")
    colorPickersHeader.textContent = "COULEURS";

    const classesHeader = document.createElement('div');
    classesHeader.classList.add("settings-header")
    classesHeader.textContent = "COURS";

    const classesB1Header = document.createElement('div');
    classesB1Header.classList.add("settings-header")
    classesB1Header.textContent = "B1";

    const classesB2Header = document.createElement('div');
    classesB2Header.classList.add("settings-header")
    classesB2Header.textContent = "B2";

    const classesB3Header = document.createElement('div');
    classesB3Header.classList.add("settings-header")
    classesB3Header.textContent = "B3";

    const classOtherHeader = document.createElement('div');
    classOtherHeader.classList.add("settings-header")
    classOtherHeader.textContent = "AUTRES";

    classesB1List = document.createElement('div');
    classesB1List.classList.add("settings-list");

    classesB2List = document.createElement('div');
    classesB2List.classList.add("settings-list");

    classesB3List = document.createElement('div');
    classesB3List.classList.add("settings-list");

    classOtherList = document.createElement('div');
    classOtherList.classList.add("settings-list");

    const promotionsList = document.createElement('div');
    promotionsList.classList.add("settings-list");

    promotionsHeader.addEventListener('click', function() 
    {
        if (promotionsList.style.display === "none" || promotionsList.style.display === "") 
        {
            promotionsList.style.display = "block"; 
        } 
        else 
        {
            promotionsList.style.display = "none";
        }
    });

    const colorList = document.createElement('div');
    colorList.classList.add("settings-list");

    colorPickersHeader.addEventListener('click', function()
    {
        if (colorList.style.display === "none" || colorList.style.display === "")
        {
            colorList.style.display = "block";
        }
        else
        {
            colorList.style.display = "none";
        }
    }
    );

    const classesList = document.createElement('div');
    classesList.classList.add("settings-list");

    classesHeader.addEventListener('click', function()
    {
        if (classesList.style.display === "none" || classesList.style.display === "")
        {
            classesList.style.display = "block"; 
        }
        else
        {
            classesList.style.display = "none";
        }
    }
    );

    classesB1Header.addEventListener('click', function()
    {
        if (classesB1List.style.display === "none" || classesB1List.style.display === "")
        {
            classesB1List.style.display = "block"; 
        }
        else
        {
            classesB1List.style.display = "none";
        }
    }
    );

    classesB2Header.addEventListener('click', function()
    {
        if (classesB2List.style.display === "none" || classesB2List.style.display === "")
        {
            classesB2List.style.display = "block"; 
        }
        else
        {
            classesB2List.style.display = "none";
        }
    }
    );

    classesB3Header.addEventListener('click', function()
    {
        if (classesB3List.style.display === "none" || classesB3List.style.display === "")
        {
            classesB3List.style.display = "block"; 
        }
        else
        {
            classesB3List.style.display = "none";
        }
    }
    );

    classOtherHeader.addEventListener('click', function()
    {
        if (classOtherList.style.display === "none" || classOtherList.style.display === "")
        {
            classOtherList.style.display = "block"; 
        }
        else
        {
            classOtherList.style.display = "none";
        }
    }
    );
    
    settingsContainer.appendChild(promotionsHeader);
    settingsContainer.appendChild(promotionsList);

    settingsContainer.appendChild(colorPickersHeader);
    settingsContainer.appendChild(colorList);

    settingsContainer.appendChild(classesHeader);
    settingsContainer.appendChild(classesList);

    classesList.appendChild(classesB1Header);
    classesList.appendChild(classesB1List);
    classesList.appendChild(classesB2Header);
    classesList.appendChild(classesB2List);
    classesList.appendChild(classesB3Header);
    classesList.appendChild(classesB3List);
    classesList.appendChild(classOtherHeader);
    classesList.appendChild(classOtherList);

    promotions.forEach(promotion => 
    {
        const promotionDiv = document.createElement('div');
        promotionDiv.classList.add("settings-list-sub-div");

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.value = promotion.promotion_id;
        checkbox.name = promotion.promotion_label;
        checkbox.classList.add("settings-checkbox");

        if (localStorage.getItem('promotions') !== null) 
        {
            const promotionsChecked = JSON.parse(localStorage.getItem('promotions'));
            checkbox.checked = promotionsChecked.includes(promotion.promotion_id);
        }

        checkbox.addEventListener('change', function() 
        {
            let promotions = JSON.parse(localStorage.getItem('promotions')) || [];
            if (this.checked) 
            {
                promotions.push(promotion.promotion_id);
            } 
            else 
            {
                promotions = promotions.filter(id => id !== promotion.promotion_id);
            }
            localStorage.setItem('promotions', JSON.stringify(promotions));

            fillColorPickerList(colorList);

            customSectionPromotion();

        });

        const label = document.createElement('label');
        label.textContent = promotion.promotion_label;

        promotionDiv.appendChild(checkbox);
        promotionDiv.appendChild(label);

        promotionsList.appendChild(promotionDiv);
    });

    fillColorPickerList(colorList);
    fillClasses();
    
}

function fillColorPickerList(colorList)
{
    colorList.innerHTML = '';

    const colorB1Div = document.createElement('div');
    colorB1Div.classList.add("settings-color-div", "settings-list-sub-div");
    colorList.appendChild(colorB1Div);

    const colorB1Label = document.createElement('p');
    colorB1Label.textContent = "B1";
    colorB1Div.appendChild(colorB1Label);


    const colorB1 = document.createElement('input');
    colorB1.type = 'color';
    colorB1.style.pointerEvents = "auto";

    if (localStorage.getItem('colorB1') !== null) 
    {
        colorB1.value = localStorage.getItem('colorB1');
    }

    colorB1.addEventListener('change', function()
    {
        localStorage.setItem('colorB1', this.value);
        updateColors();
    });

    colorB1Div.appendChild(colorB1);

    const colorB2Div = document.createElement('div');
    colorB2Div.classList.add("settings-color-div", "settings-list-sub-div");
    colorList.appendChild(colorB2Div);

    const colorB2Label = document.createElement('p');
    colorB2Label.textContent = "B2";
    colorB2Div.appendChild(colorB2Label);

    const colorB2 = document.createElement('input');
    colorB2.type = 'color';
    colorB2.style.pointerEvents = "auto";

    if (localStorage.getItem('colorB2') !== null)
    {
        colorB2.value = localStorage.getItem('colorB2');
    }

    colorB2.addEventListener('change', function()
    {
        localStorage.setItem('colorB2', this.value);
        updateColors();
    });

    colorB2Div.appendChild(colorB2);

    const colorB3Div = document.createElement('div');
    colorB3Div.classList.add("settings-color-div", "settings-list-sub-div");
    colorList.appendChild(colorB3Div);

    const colorB3Label = document.createElement('p');
    colorB3Label.textContent = "B3";
    colorB3Div.appendChild(colorB3Label);

    const colorB3 = document.createElement('input');
    colorB3.type = 'color';
    colorB3.style.pointerEvents = "auto";

    if (localStorage.getItem('colorB3') !== null) 
    {
        colorB3.value = localStorage.getItem('colorB3');
    }

    colorB3.addEventListener('change', function()
    {
        localStorage.setItem('colorB3', this.value);
        updateColors();
    });

    colorB3Div.appendChild(colorB3);

    const colorOtherDiv = document.createElement('div');
    colorOtherDiv.classList.add("settings-color-div", "settings-list-sub-div");
    colorList.appendChild(colorOtherDiv);

    const colorOtherLabel = document.createElement('p');
    colorOtherLabel.textContent = "AUTRES";
    colorOtherDiv.appendChild(colorOtherLabel);

    const colorOther = document.createElement('input');
    colorOther.type = 'color';
    colorOther.style.pointerEvents = "auto";

    if (localStorage.getItem('colorOther') !== null)
    {
        colorOther.value = localStorage.getItem('colorOther');
    }

    colorOther.addEventListener('change', function()
    {
        localStorage.setItem('colorOther', this.value);
        updateColors();
    }
    );

    colorOtherDiv.appendChild(colorOther);
    
    }


function fillClasses()
{

    classesB1List.innerHTML = '';
    classesB2List.innerHTML = '';
    classesB3List.innerHTML = '';
    classOtherList.innerHTML = '';

    classes.forEach((year, index) =>
    {
        if(year)
        {
            year.forEach((classe) =>
            {
                const classDiv = document.createElement('div');
                classDiv.classList.add("settings-list-sub-div");

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.value = classe;
                checkbox.name = classe;
                checkbox.style.marginRight = "10px";
                checkbox.style.opacity = "1";
                checkbox.style.position = "relative";
                checkbox.style.pointerEvents = "auto";
                checkbox.checked = true;

                if (localStorage.getItem('classes') !== null) 
                {
                    const classUnchecked = JSON.parse(localStorage.getItem('classes'));
                    checkbox.checked = !classUnchecked.some(item => item.classe === classe && item.year === index);
                }

                checkbox.addEventListener('change', function()
                {
                    let promotions = JSON.parse(localStorage.getItem('classes')) || [];
                    if (!this.checked) 
                    {
                        // need to store if the class is B1, B2 or B3
                        let newClass = 
                        {
                            classe: classe,
                            year: index
                        }
                        promotions.push(newClass);
                    } 
                    else 
                    {
                        promotions = promotions.filter(item => item.classe !== classe);
                    }
                    localStorage.setItem('classes', JSON.stringify(promotions));

                    customSectionPromotion();
                });


                const label = document.createElement('label');
                label.textContent = classe;

                classDiv.appendChild(checkbox);
                classDiv.appendChild(label);

                if(index == 0)
                {
                    classOtherList.appendChild(classDiv);
                }
                else if(index == 1)
                {
                    classesB1List.appendChild(classDiv);
                }
                else if(index == 2)
                {
                    classesB2List.appendChild(classDiv);
                }
                else if(index == 3)
                {
                    classesB3List.appendChild(classDiv);
                }
            });
        }
        

    }

    );
}

function openSettings() 
{
    console.log(settingsContainer);
    settingsContainer.style.display = "block";
    
}
function closeSettings()
{
    settingsContainer.style.display = "none";
}

function updateColors()
{
    const currentMode = document.querySelector('.fc-button-active').textContent;

    let events = document.querySelectorAll('.fc-list-event, .fc-event, .fc-event-start, .fc-event-end, .fc-event-past');
    events.forEach(event => 
    {
        let titleContent = getEventTitleElement(event, currentMode);
        let title = titleContent.split('-')[0];
        if(title.includes('UE '))
        {
            title = titleContent.split('-')[1];
            // remove first space
            title = title.substring(1);
        }

        let length = 0; 
        if (titleContent.includes('[') && !titleContent.endsWith('[')) {
            length = titleContent.split('[')[1].length;
        }

        let classYear = 0;
        if(length > 1)
        {
            years = [];
            let i = 0;
            while(i < titleContent.length)
            {
                if(titleContent[i] == '[')
                {
                    // check if there is a space after the [, cause they fucked up the format
                    
                    if(titleContent[i+1] == ' ')
                    {
                        years.push(titleContent[i+2]);
                        i++;
                    }
                    else
                    {
                        years.push(titleContent[i+1]);
                    }                       
                }
                i++;
            }
            
            if(years.length >= 1)
            {
                let allSameYear = years.every( (val, i, arr) => val === arr[0] );
                if(allSameYear)
                {
                    classYear = years[0];
                }
                else
                {
                    classYear = 0;
                }
            }
            
        }

        let colors = ["colorOther", "colorB1", "colorB2", "colorB3"];

        classes.forEach((year, index) =>
        {
            if(year && year.includes(title) && classYear == index)
            {
                let color = localStorage.getItem(colors[index]);
                if(color !== null)
                {
                    event.style.setProperty("background-color", color, "important");
                    event.style.setProperty("border-color", color, "important");
                    
                }
            }
        });
    });
}

function getEventTitleElement(event, mode)
{
    let titleElement;

    if(mode == 'liste')
    {
        titleElement = event.querySelector('.fc-list-event-title a').textContent;
    }
    else if(mode == 'jour')
    {
        titleElement = event.querySelector('.fc-event-title').textContent;
    }
    else if(mode == 'semaine')
    {
        titleElement = event.querySelector('.fc-event-title').textContent;
    }
    else if(mode == 'mois')
    {
        titleElement = event.querySelector('.fc-event-title').textContent;
    }

    return titleElement;
}


document.addEventListener('click', function(event)
{
    if(event.target.classList.contains('fc-next-button') || event.target.classList.contains('fc-prev-button') || event.target.classList.contains('fc-today-button') || event.target.classList.contains('fc-icon-chevron-right') || event.target.classList.contains('fc-icon-chevron-left') || event.target.classList.contains('fc-icon-chevron-up') || event.target.classList.contains('fc-listWeek-button') || event.target.classList.contains('fc-timeGridDay-button') || event.target.classList.contains('fc-timeGridWeek-button')  || event.target.classList.contains('fc-dayGridMonth-button'))
    {
        updateColors();
    }
});





